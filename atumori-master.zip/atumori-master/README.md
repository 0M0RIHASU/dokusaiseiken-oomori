# 熱盛ジェネレーター

「熱盛」が商標登録されたため公開停止

ソースコードも削除予定

## 使用ライブラリ

* [Spectrum](https://github.com/bgrins/spectrum)

## 使用フォント

* [Noto Sans CJK JP](https://www.google.com/get/noto/#sans-jpan)