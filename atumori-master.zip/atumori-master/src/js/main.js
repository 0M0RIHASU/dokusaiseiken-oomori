$(function() {
	initSvg();
	initOption();
})
